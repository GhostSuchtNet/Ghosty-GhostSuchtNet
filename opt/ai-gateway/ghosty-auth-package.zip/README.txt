Ghosty Auth Package

Dateien:
- access-admin.js: Zugangscodes erzeugen/verwalten
- auth.js: Login, Sessions, 3 Fehlversuche, 3h IP-Sperre, Rechteprüfung
- server.js: AI-Gateway mit Auth
- index.html: Ghosty-Frontend mit Zugangscode-Login
- .env.example: neue Umgebungsvariablen

Benötigt:
npm install mysql2 cookie-parser

WICHTIG:
- Vor server.js/index.html immer Backups machen.
- .env niemals öffentlich ablegen.
- Logging/GeoIP ist ABSICHTLICH noch nicht enthalten.
- Erst Auth vollständig testen, danach Logging bauen.
